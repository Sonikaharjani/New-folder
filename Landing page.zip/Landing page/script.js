document.getElementById("cta-button").addEventListener("click",function(){
    alert("Welcome! start managing tasks efficiently.");
});
document.getElementById("contact-form").addEventListener("submit", function(event){
    event.preventDefault();
    alert("thank you for reaching out!");
});