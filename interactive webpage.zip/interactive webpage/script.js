function selectBox(box, detailsId) {
    // Remove 'selected' class from all boxes
    document
      .querySelectorAll(".box")
      .forEach((b) => b.classList.remove("selected"));
  
    // Hide all details sections
    document
      .querySelectorAll(".details")
      .forEach((d) => (d.style.display = "none"));
  
    // Add 'selected' class to the clicked box
    box.classList.add("selected");
    box.querySelector('input[type="radio"]').checked = true;
  
    // Show the corresponding details section
    const details = document.getElementById(detailsId);
    details.style.display = "block";
  
    // Remove any existing event listener before adding a new one
    document.removeEventListener("click", outsideClickHandler);
  
    // Delay adding the event listener to prevent immediate hiding
    setTimeout(() => {
      document.addEventListener("click", outsideClickHandler);
    }, 0);
  }
  
  function outsideClickHandler(event) {
    // Check if the clicked element is NOT inside .details or .box
    if (!event.target.closest(".details") && !event.target.closest(".box")) {
      document
        .querySelectorAll(".details")
        .forEach((d) => (d.style.display = "none"));
      document
        .querySelectorAll(".box")
        .forEach((b) => b.classList.remove("selected"));
      document.removeEventListener("click", outsideClickHandler);
    }
  }